
  $(document).ready(function(){
    $('.librarybtn').click(function(e){
      e.preventDefault()
      alert('we are about to')
    })
  })
