<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="{{ asset('css/style.css') }}" rel="stylesheet">
    <link href="{{ asset('css/fontcss/all.min.css') }}" rel="stylesheet">
    <link href="{{ asset('css/bootstrap.min.css') }}" rel="stylesheet">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <h3 class="text-center text-success">Welcome to this Platform</h3>
        <hr>
        <div class="row">
            <div class="col-lg-8 col-md-10 col-sm-12">
                <form action="#" method="POST" id="registerform">
                    @csrf
                    <div class="form-group mb-2">
                        <label for=""><b>First Name</b></label>
                        <input type="text" name="firstname" placeholder="Enter your First Name" class="form-control">
                        <div class="invalid-feedback"></div>
                    </div>
                    <div class="form-group mb-2">
                        <label for=""><b>Last Name</b></label>
                        <input type="text" name="lastname" placeholder="Enter your Last Name" class="form-control">
                        <div class="invalid-feedback"></div>
                    </div>
                    <div class="form-group mb-2">
                        <label for=""><b>Phone Number</b></label>
                        <input type="phone" name="phone" placeholder="Enter Phone Number" class="form-control">
                        <div class="invalid-feedback"></div>
                    </div>
                    <div class="form-group mb-2">
                        <label for=""><b>Email</b></label>
                        <input type="email" name="email" placeholder="Enter your Email" class="form-control">
                        <div class="invalid-feedback"></div>
                    </div>
                    <div class="form-group mb-2">
                        <label for=""><b>Password</b></label>
                        <input type="password" name="password" placeholder="Enter your Password" class="form-control">
                        <div class="invalid-feedback"></div>
                    </div>
                    <div class="form-group mb-2">
                        <input id="regbtn" type="submit" value="REGISTER " class="form-control btn btn-danger">
                    </div>
                </form>
            </div>
            <p class="text-center">Already have an account? <a href="/loginuser">LOG IN</a></p>
        </div>
    </div>
  
<script src="{{ asset('js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('js/jquery.min.js') }}"></script>
<script src="{{ asset('js/functions.js') }}"></script>
<script src="{{ asset('js/fontjs/all.min.js') }}"></script>
<script>
    $(document).ready(function(){
       //Register Books
     $('#registerform').submit(function(e){
         $('#regbtn').val('PLEASE WAIT...');
         e.preventDefault();
         var formdata = new FormData($(this)[0]);
         $.ajax({
             method: 'POST',
             url: '/registeruser',
             contentType: false,
            processData: false,
            //dataType: 'json',
            data: formdata,
            success: function(res) {
                console.log(res);
                // if (res.status == 400) {
                // $('#bookregbtn').val('ADD BOOK');
                // showError('booknumber', res.messages.booknumber);
                // showError('category', res.messages.category);
                // showError('class', res.messages.class);
                // showError('subject', res.messages.subject);
                // showError('publisher', res.messages.publisher);
                // } else if(res.status == 200){
                // $('#bookform')[0].reset();
                // $('#bookregbtn').val('ADD BOOK');
                // $('#booksregres').removeClass('d-none');
                // $('#booksregres').text(res.messages);
                // $('#booksmodal').modal('hide');
                // fetchbooks();   
                // }
            }
         })
        })
 
    })
</script>
</body>
</html>