<?php

namespace App\Http\Controllers;
use App\Models\User;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;

class UserController extends Controller
{
    //Add New User
    public function addnewuser(Request $req){
        return ['message' => 'data Reached'];
    }
    //Return view for registering a new user
    public function registerview(){
        return view('apifiles.register');
    }
    //Return view for login 
    public function loginuser(){
        return view('apifiles.login');
    }
    //Register new web user
    public function registerwebuser(Request $req){
        $validator = Validator::make($req->all(),[
            'firstname' => 'required',
            'lastname' => 'required',
            'phone' => 'required|unique:users',
            'email' => 'required|unique:users',
            'password' => 'required'
        ],
    [
        'phone.unique' => 'This Phone Number is already registered',
        'email.unique' => 'This Email is already Registered'
    ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'messages' => $validator->getMessageBag()
            ]);
        } else {
            $user = new User;
            $user->fname = $req->firstname;
            $user->lname = $req->lastname;
            $user->phone = $req->phone;
            $user->email = $req->email;
            $user->pass = $req->password;
            $user->save();
            return response()->json([
                'status' => 200,
                'messages' => 'You have successfully created your account'
            ]);
        }
    }
    //Register api user
    public function registerapiuser(Request $req){
        $validator = Validator::make($req->all(),[
            'firstname' => 'required',
            'lastname' => 'required',
            'phone' => 'required|unique:users',
            'email' => 'required|unique:users',
            'password' => 'required'
        ],
    [
        'phone.unique' => 'This Phone Number is already registered',
        'email.unique' => 'This Email is already Registered'
    ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'messages' => $validator->getMessageBag()
            ]);
        } else {
            $user = new User;
            $user->fname = $req->firstname;
            $user->lname = $req->lastname;
            $user->phone = $req->phone;
            $user->email = $req->email;
            $user->pass = $req->password;
            $user->save();
            return response()->json([
                'status' => 200,
                'messages' => 'You have successfully created your account'
            ]);
        }
    }
}
